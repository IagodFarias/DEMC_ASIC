# Cadence Genus(TM) Synthesis Solution, Version 21.10-p002_1, built Aug 20 2021 10:13:13

# Date: Thu Oct 22 23:25:50 2026
# Host: semb (x86_64 w/Linux 4.18.0-553.137.1.el8_10.x86_64) (20cores*28cpus*1physical cpu*Intel(R) Core(TM) i7-14700K 33792KB)
# OS:   Rocky Linux release 8.10 (Green Obsidian)

source /home/mateusmaia45/Documentos/DEMC_ASIC/artigo_dynecc/scripts/cadence/run_synth.tcl
